import time
import random
import sys
import os
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

def get_random_delay(base_delay):
    """Return a randomized delay to mimic human behavior"""
    return base_delay * (0.8 + 0.4 * random.random())  # 80-120% of base delay

def human_like_mouse_move(driver, element):
    """Simulate human-like mouse movement to element"""
    try:
        action = ActionChains(driver)
        action.move_to_element_with_offset(element, random.randint(-5,5), random.randint(-5,5))
        action.perform()
        time.sleep(get_random_delay(0.3))
        action.move_to_element(element)
        action.perform()
        time.sleep(get_random_delay(0.2))
    except:
        pass

def get_random_user_agent():
    """Return a random user agent to rotate between requests"""
    user_agents = [
        # Chrome on Windows
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36",
        # Chrome on Mac
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        # Firefox
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0"
    ]
    return random.choice(user_agents)

def process_tab(driver, tab, cycle_num, base_delay):
    """Process a single tab for ad clicking"""
    driver.switch_to.window(tab)
    current_delay = get_random_delay(base_delay)
    
    print(f"\n--- Processing tab {driver.current_window_handle} ---")
    print(f"Current URL: {driver.current_url}")
    
    # Random scroll to mimic human behavior
    scroll_amount = random.randint(200, 800)
    driver.execute_script(f"window.scrollBy(0, {scroll_amount})")
    time.sleep(current_delay * 0.3)
    
    main_window = driver.current_window_handle

    ad_selectors = [
        "a[href*='click']", "a[href*='ad']", "a[href*='Ad']", "a[href*='promo']",
        "a[href*='sponsor']", "a[href*='offer']", "a[target='_blank']",
        "iframe", "iframe[src*='ad']", 
        "div[class*='ad']", "div[class*='Ad']", "div[class*='banner']",
        "div[id*='ad']", "div[id*='Ad']", "button[onclick*='ad']",
        "img[src*='ad']", "img[onclick*='ad']"
    ]
    
    # Shuffle selectors to vary detection pattern
    random.shuffle(ad_selectors)
    
    potential_ad_elements = []
    for selector in ad_selectors:
        try:
            elements = driver.find_elements(By.CSS_SELECTOR, selector)
            if elements:
                potential_ad_elements.extend(elements)
                time.sleep(get_random_delay(0.1))  # Small delay between finds
        except:
            continue

    if not potential_ad_elements:
        print("No potential ad elements found on the page.")
    else:
        print(f"Found {len(potential_ad_elements)} potential ad elements.")
        # Randomize which elements to interact with
        random.shuffle(potential_ad_elements)
        
        for idx, element in enumerate(potential_ad_elements[:random.randint(1, 3)]):  # Click 1-3 random elements
            try:
                print(f"\nAttempting to click element {idx+1}")
                
                # Human-like mouse movement
                human_like_mouse_move(driver, element)
                
                tag_name = element.tag_name.lower()
                href = element.get_attribute("href") if tag_name == "a" else None
                print(f"Element type: {tag_name}, href: {href}")
                
                if tag_name == "iframe":
                    print("Found iframe, attempting to switch to it")
                    try:
                        driver.switch_to.frame(element)
                        iframe_clickables = driver.find_elements(By.CSS_SELECTOR, "a, button, div[onclick]")
                        if iframe_clickables:
                            random.choice(iframe_clickables).click()
                            print("Clicked random element inside iframe")
                            time.sleep(get_random_delay(1))
                        driver.switch_to.default_content()
                    except Exception as e:
                        print(f"Couldn't interact with iframe: {str(e)}")
                        driver.switch_to.default_content()
                    continue
                
                # Random delay before click
                time.sleep(get_random_delay(0.5))
                
                try:
                    element.click()
                    print("Performed regular click")
                except:
                    driver.execute_script("arguments[0].click();", element)
                    print("Performed JavaScript click")
                
                time.sleep(get_random_delay(1))
                
                # Random chance to move mouse away after click
                if random.random() > 0.3:
                    action = ActionChains(driver)
                    action.move_by_offset(random.randint(10,50), random.randint(10,50))
                    action.perform()
                
                if len(driver.window_handles) > 1:
                    new_window = [window for window in driver.window_handles if window != main_window][0]
                    driver.switch_to.window(new_window)
                    print(f"New tab opened with URL: {driver.current_url}")
                    
                    # Random time spent on the ad page
                    ad_view_time = get_random_delay(base_delay * 0.5)
                    print(f"Waiting {ad_view_time:.1f} seconds before closing...")
                    time.sleep(ad_view_time)
                    
                    driver.close()
                    driver.switch_to.window(main_window)
                    print("Returned to main window")
                else:
                    print("No new tab opened")
                    
            except Exception as e:
                print(f"Could not interact with element {idx+1}: {str(e)}")

    print("Refreshing the tab after random delay")
    time.sleep(get_random_delay(base_delay))
    driver.refresh()

def automated_ad_clicker_chrome(url, loop_count=10, base_delay=5):
    # Set up Chrome options for stealth
    chrome_options = ChromeOptions()
    
    # Headless mode - no browser window
    chrome_options.add_argument("--headless")
    chrome_options.add_argument("--disable-gpu")
    
    # Disable automation flags
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option("useAutomationExtension", False)
    
    # Random user agent
    chrome_options.add_argument(f"user-agent={get_random_user_agent()}")
    
    # Other settings to appear more natural
    chrome_options.add_argument("--start-maximized")
    chrome_options.add_argument("--disable-popup-blocking")
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_argument("--disable-extensions")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--no-sandbox")
    
    # Initialize the Chrome WebDriver
    driver = webdriver.Chrome(
        service=ChromeService(ChromeDriverManager().install()), 
        options=chrome_options
    )
    
    # Further hide automation by overwriting navigator.webdriver property
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": """
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            })
        """
    })

    try:
        # Open initial tab
        driver.get(url)
        time.sleep(base_delay * 0.5)
        
        # Open 9 additional tabs (total 10 tabs)
        for _ in range(9):
            driver.execute_script("window.open('');")
            time.sleep(get_random_delay(0.5))
        
        # Get all tab handles
        tabs = driver.window_handles
        
        # Load the URL in all tabs
        for tab in tabs:
            driver.switch_to.window(tab)
            driver.get(url)
            time.sleep(get_random_delay(0.5))
        
        for i in range(loop_count):
            print(f"\n--- Cycle {i+1}/{loop_count} ---")
            
            # Process each tab
            for tab in tabs:
                try:
                    process_tab(driver, tab, i+1, base_delay)
                except Exception as e:
                    print(f"Error processing tab {tab}: {str(e)}")
                    # Try to recover the tab by refreshing
                    try:
                        driver.switch_to.window(tab)
                        driver.refresh()
                        time.sleep(base_delay)
                    except:
                        print("Could not recover tab, continuing with others")

            if i < loop_count - 1:
                next_delay = get_random_delay(base_delay * 2)  # Longer delay between cycles
                print(f"Waiting {next_delay:.1f} seconds before next cycle...")
                time.sleep(next_delay)

    except KeyboardInterrupt:
        print("\nScript interrupted by user.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
    finally:
        driver.quit()

if __name__ == "__main__":
    target_url = "https://movie00-99.blogspot.com/"
    cycles = 100000
    base_delay = 5  # Base delay in seconds (will be randomized)
    
    # Run in a loop with restart capability
    while True:
        try:
            automated_ad_clicker_chrome(target_url, cycles, base_delay)
        except Exception as e:
            print(f"Script crashed with error: {str(e)}")
            print("Restarting in 30 seconds...")
            time.sleep(30)