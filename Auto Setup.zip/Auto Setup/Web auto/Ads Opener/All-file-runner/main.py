import subprocess
import os
import time
import random
import logging
import sys
import win32con
import win32process
import win32gui
import win32api

# Configure logging
logging.basicConfig(
    filename='process_manager.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# List of Python files to run
python_files = [
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome\copy- 1\main.py",
    r"C:\Auto Setup\Web auto\ODA App\main.py",
]

# Track process start attempts to prevent rapid restart loops
process_attempts = {file: 0 for file in python_files}
MAX_ATTEMPTS = 5  # Maximum restart attempts before giving up for a while
ATTEMPT_RESET_TIME = 3600  # 1 hour in seconds

def hide_console_window(pid):
    """Hide the console window of the process"""
    try:
        def callback(hwnd, hwnds):
            if win32gui.IsWindowVisible(hwnd):
                _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
                if found_pid == pid:
                    hwnds.append(hwnd)
            return True
        
        hwnds = []
        win32gui.EnumWindows(callback, hwnds)
        for hwnd in hwnds:
            win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
    except Exception as e:
        logging.error(f"Error hiding window for PID {pid}: {str(e)}")

def human_like_delay():
    """Random delay to simulate human behavior"""
    delay = random.uniform(1.5, 10.5)  # Random delay between 1.5 to 10.5 seconds
    time.sleep(delay)

def run_hidden_process(command, file_path):
    """Run a process with hidden window"""
    try:
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        process = subprocess.Popen(
            command,
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        )
        
        # Additional hiding for extra reliability
        hide_console_window(process.pid)
        
        # Reset attempt counter on successful start
        process_attempts[file_path] = 0
        
        logging.info(f"Successfully started process: {file_path} with PID {process.pid}")
        return process
    except Exception as e:
        process_attempts[file_path] += 1
        logging.error(f"Error starting hidden process {file_path} (attempt {process_attempts[file_path]}): {str(e)}")
        return None

def check_and_restart_processes(processes):
    """Check all processes and restart any that have stopped"""
    for file in python_files.copy():  # Use copy to avoid modification during iteration
        try:
            proc = processes.get(file)
            
            # Check if process needs to be started or restarted
            if proc is None or proc.poll() is not None:
                if os.path.exists(file):
                    # Check if we've exceeded max attempts
                    if process_attempts[file] >= MAX_ATTEMPTS:
                        last_attempt_time = process_attempts.get(f"{file}_last_attempt", 0)
                        if time.time() - last_attempt_time > ATTEMPT_RESET_TIME:
                            # Reset attempts after the cooldown period
                            process_attempts[file] = 0
                        else:
                            logging.warning(f"Skipping {file} - too many failed attempts. Will retry later.")
                            continue
                    
                    logging.info(f"Starting/Restarting process: {file}")
                    
                    # Human-like delay before starting
                    human_like_delay()
                    
                    # Run the process hidden
                    processes[file] = run_hidden_process(['python', file], file)
                    
                    if processes[file] is None:
                        logging.error(f"Failed to start process: {file}")
                        process_attempts[f"{file}_last_attempt"] = time.time()
                        if process_attempts[file] >= MAX_ATTEMPTS:
                            logging.error(f"Max restart attempts reached for {file}. Will pause restart attempts.")
                    else:
                        # Successfully started
                        process_attempts[file] = 0
                else:
                    logging.warning(f"File not found: {file}")
                    # Remove from monitoring if file doesn't exist
                    if file in processes:
                        del processes[file]
                    if file in python_files:
                        python_files.remove(file)
            
            # Random check interval to simulate human behavior
            time.sleep(random.uniform(3, 15))
            
        except Exception as e:
            logging.error(f"Error in monitoring loop for {file}: {str(e)}")
            time.sleep(30)  # Longer delay after error

def run_and_monitor(files):
    """Monitor and maintain the processes"""
    processes = {}
    
    while True:
        check_and_restart_processes(processes)
        
        # Periodically reset attempt counters for processes that might have recovered
        if random.random() < 0.1:  # 10% chance to check for reset opportunities
            current_time = time.time()
            for file in list(process_attempts.keys()):
                if file.endswith("_last_attempt"):
                    original_file = file.replace("_last_attempt", "")
                    if current_time - process_attempts[file] > ATTEMPT_RESET_TIME:
                        process_attempts[original_file] = 0
                        logging.info(f"Reset attempt counter for {original_file} after cooldown period")

def main():
    try:
        # Hide our own console window if running in console mode
        hide_console_window(os.getpid())
        
        logging.info("Process manager started")
        run_and_monitor(python_files)
    except KeyboardInterrupt:
        logging.info("Process manager stopped by user")
        sys.exit(0)
    except Exception as e:
        logging.critical(f"Fatal error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # For complete stealth, you could package this as a Windows service
    # But this version will run hidden as a regular script
    main()
