import os
import sys
import time
import random
import logging
import psutil
import win32con
import win32process
import win32gui

# Configure logging
logging.basicConfig(
    filename='python_killer.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def hide_console():
    """Hide the console window"""
    try:
        hwnd = win32gui.GetForegroundWindow()
        win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
    except Exception as e:
        logging.error(f"Error hiding console: {str(e)}")

def human_like_delay(min_sec=0.5, max_sec=3.0):
    """Random delay to simulate human behavior"""
    delay = random.uniform(min_sec, max_sec)
    time.sleep(delay)

def get_python_processes():
    """Get all Python processes except this one"""
    current_pid = os.getpid()
    python_processes = []
    
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            # Match Python processes (including pythonw.exe)
            if proc.info['name'].lower() in ('python.exe', 'pythonw.exe'):
                if proc.info['pid'] != current_pid:
                    python_processes.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    
    return python_processes

def kill_process(proc):
    """Kill a process with human-like behavior"""
    try:
        proc_name = proc.name()
        proc_pid = proc.pid
        
        logging.info(f"Terminating process: {proc_name} (PID: {proc_pid})")
        
        # Simulate human hesitation
        human_like_delay(0.3, 1.5)
        
        # Try graceful termination first
        proc.terminate()
        
        # Wait a bit to see if it closes
        human_like_delay(0.5, 2.0)
        
        if proc.is_running():
            # Force kill if still running
            human_like_delay(0.2, 1.0)
            proc.kill()
            
    except Exception as e:
        logging.error(f"Error killing process {proc.pid}: {str(e)}")

def main():
    try:
        # Hide the console window immediately
        hide_console()
        
        logging.info("Python process killer started")
        
        # Get initial list of Python processes
        targets = get_python_processes()
        logging.info(f"Found {len(targets)} Python processes to terminate")
        
        # Kill processes with human-like timing
        for proc in targets:
            kill_process(proc)
        
        # Verify all processes are closed
        remaining = get_python_processes()
        retry_count = 0
        
        while remaining and retry_count < 3:
            human_like_delay(1.0, 3.0)
            logging.info(f"Retry {retry_count + 1}: {len(remaining)} processes remaining")
            
            for proc in remaining:
                kill_process(proc)
            
            remaining = get_python_processes()
            retry_count += 1
        
        if remaining:
            logging.warning(f"{len(remaining)} Python processes could not be terminated")
        else:
            logging.info("All Python processes terminated successfully")
        
        logging.info("Process killer exiting")
        
    except Exception as e:
        logging.critical(f"Fatal error: {str(e)}")
    finally:
        sys.exit(0)

if __name__ == "__main__":
    # For complete stealth, compile with PyInstaller using --noconsole --onefile
    main()