import os
import time
from datetime import datetime

def schedule_shutdown(shutdown_time_str):
    shutdown_time = datetime.strptime(shutdown_time_str, "%H:%M")
    while True:
        now = datetime.now()
        if now.hour == shutdown_time.hour and now.minute == shutdown_time.minute:
            if os.name == 'nt':  # Windows
                os.system("shutdown /s /t 1")
            else:  # Unix/Linux/Mac
                os.system("shutdown -h now")
            break
        time.sleep(30)

if __name__ == "__main__":
    shutdown_time_input = input("Enter shutdown time (HH:MM, 24-hour format): ")
    print(f"System will shutdown at {shutdown_time_input}.")
    schedule_shutdown(shutdown_time_input)