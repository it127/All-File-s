import psutil
import time
import os
import sys
import platform
from datetime import datetime

class SystemOptimizer:
    def __init__(self):
        self.system_platform = platform.system()
        self.user_processes = set()
        self.last_optimization_time = time.time()
        self.optimization_interval = 300  # 5 minutes
        self.max_cpu_threshold = 80  # Percentage
        self.min_ram_threshold = 20  # Percentage free
        self.process_whitelist = {
            "system", "svchost", "explorer", "winlogon", "csrss", 
            "lsass", "services", "taskmgr", "python", "cmd",
            "conhost", "wininit", "spoolsv", "dwm", "ctfmon"
        }
        
    def get_active_user_processes(self):
        """Identify processes with user interaction"""
        active_processes = set()
        for proc in psutil.process_iter(['pid', 'name', 'username']):
            try:
                if proc.info['username'] and not proc.info['username'].endswith('$'):
                    active_processes.add(proc.info['name'].lower())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return active_processes
    
    def is_process_critical(self, proc_name):
        """Check if process is critical or whitelisted"""
        proc_lower = proc_name.lower()
        return (proc_lower in self.process_whitelist or 
                proc_lower.endswith('.exe') and proc_lower.split('.')[0] in self.process_whitelist)
    
    def optimize_system(self):
        """Main optimization logic"""
        current_time = time.time()
        if current_time - self.last_optimization_time < self.optimization_interval:
            return
        
        self.last_optimization_time = current_time
        self.user_processes = self.get_active_user_processes()
        
        cpu_usage = psutil.cpu_percent(interval=1)
        mem = psutil.virtual_memory()
        mem_usage = mem.percent
        
        print(f"\n[{datetime.now()}] System Status - CPU: {cpu_usage}%, RAM: {mem_usage}% used")
        
        if cpu_usage < self.max_cpu_threshold and (100 - mem_usage) > self.min_ram_threshold:
            print("System within optimal thresholds. No optimization needed.")
            return
        
        print("Performing system optimization...")
        
        terminated_count = 0
        for proc in psutil.process_iter(['pid', 'name', 'memory_percent', 'cpu_percent']):
            try:
                proc_name = proc.info['name'].lower()
                
                # Skip critical/system processes and user-active processes
                if (self.is_process_critical(proc_name) or 
                    proc_name in self.user_processes):
                    continue
                
                # Check if process is using significant resources or is hung
                cpu_pct = proc.info['cpu_percent'] or 0
                mem_pct = proc.info['memory_percent'] or 0
                
                if (cpu_pct > 10 or mem_pct > 5 or 
                    (cpu_pct > 0 and time.time() - proc.create_time() > 3600)):
                    print(f"Terminating {proc_name} (PID: {proc.info['pid']}) - CPU: {cpu_pct}%, MEM: {mem_pct}%")
                    proc.terminate()
                    terminated_count += 1
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception as e:
                print(f"Error handling process {proc.info.get('name')}: {str(e)}")
        
        print(f"Optimization complete. Terminated {terminated_count} processes.")
        
        # Set process priority for system optimization
        self.adjust_process_priorities()
    
    def adjust_process_priorities(self):
        """Adjust priorities of system processes for better dual-core performance"""
        try:
            current_process = psutil.Process(os.getpid())
            if self.system_platform == 'Windows':
                current_process.nice(psutil.HIGH_PRIORITY_CLASS)
            else:
                current_process.nice(-10)  # Higher priority on Unix-like systems
            
            for proc in psutil.process_iter(['pid', 'name']):
                try:
                    proc_name = proc.info['name'].lower()
                    if proc_name in {'explorer.exe', 'dwm.exe'} and self.system_platform == 'Windows':
                        p = psutil.Process(proc.info['pid'])
                        p.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                    
        except Exception as e:
            print(f"Error adjusting priorities: {str(e)}")
    
    def check_admin_privileges(self):
        """Check if running with admin privileges"""
        if self.system_platform == 'Windows':
            try:
                import ctypes
                return ctypes.windll.shell32.IsUserAnAdmin() != 0
            except:
                return False
        else:
            try:
                return os.getuid() == 0
            except AttributeError:
                return False
    
    def monitor_system(self):
        """Main monitoring loop"""
        print("System Optimizer started. Running in background...")
        
        if not self.check_admin_privileges():
            print("Warning: Not running with administrator privileges. Some functions may be limited.")
        
        print("Press Ctrl+C to exit.")
        
        try:
            while True:
                self.optimize_system()
                time.sleep(60)  # Check every minute
        except KeyboardInterrupt:
            print("\nOptimizer shutting down gracefully...")
            sys.exit(0)

if __name__ == "__main__":
    if platform.system() not in ['Windows', 'Linux']:
        print("This optimizer is designed for Windows and Linux systems.")
        sys.exit(1)
    
    optimizer = SystemOptimizer()
    optimizer.monitor_system()