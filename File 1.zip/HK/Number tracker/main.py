import phonenumbers
from phonenumbers import geocoder, carrier

def get_phone_info(phone_number, region='US'):
    try:
        parsed_number = phonenumbers.parse(phone_number, region)
        if not phonenumbers.is_valid_number(parsed_number):
            return "Invalid phone number."

        location = geocoder.description_for_number(parsed_number, "en")
        service = carrier.name_for_number(parsed_number, "en")
        return f"Location: {location}\nService Provider: {service}"
    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    phone_number = input("Enter phone number with country code (e.g., +14155552671): ")
    info = get_phone_info(phone_number)
    print(info)