# app.py - Python Flask Backend Server for Callanix AI Assistant

# Import necessary libraries
import os
from flask import Flask, request, jsonify
from flask_cors import CORS # Used to handle Cross-Origin Resource Sharing
import google.generativeai as genai # Google Generative AI SDK

# Initialize the Flask application
app = Flask(__name__)
# Enable CORS for all routes, allowing requests from your frontend HTML
CORS(app)

# IMPORTANT: For production, store your API key in an environment variable
# and access it like: os.getenv("GEMINI_API_KEY").
# For this demonstration, we are hardcoding it as per your request,
# but BE AWARE OF THE SECURITY RISKS in a real-world scenario.
# Anyone with access to this code could extract your API key.
GEMINI_API_KEY = "AIzaSyDsA1KdwkwZeniMVyCZJmH8aAN9ORNlHsI" # Your provided API Key

# Configure the Google Generative AI with your API key
genai.configure(api_key=GEMINI_API_KEY)

# Initialize the Generative Model (using gemini-2.0-flash as it's suitable for chat)
# You can choose other models based on your needs, e.g., 'gemini-pro'.
model = genai.GenerativeModel('gemini-2.0-flash')

# Define the chat endpoint
@app.route('/chat', methods=['POST'])
def chat():
    """
    Handles chat requests from the frontend.
    Receives user message, sends it to Gemini API, and returns the AI's response.
    """
    try:
        # Get JSON data from the request
        data = request.get_json()
        user_message = data.get('message')

        if not user_message:
            return jsonify({'error': 'No message provided'}), 400

        # Define the context for the AI model
        # This helps the AI understand its role and provides better responses.
        context = """You are Callanix, an AI learning assistant for CBSE, ICSE, and ICS students from class 4 to 12. 
        Provide detailed, curriculum-aligned explanations in clear, structured formats with proper headings, lists, tables when appropriate, and examples.
        Focus on academic topics including Math, Science, History, Geography, and Language Arts (grammar, literature).
        If a user asks for something outside of academics or the specified curriculum, politely decline and redirect them to academic topics.
        Ensure your responses are easy to understand for students in the specified age group."""

        # Combine context and user message for the prompt
        full_prompt = f"{context}\n\nUser: {user_message}"

        # Generate content using the Gemini model
        # The generate_content method sends the prompt to the AI and gets a response.
        response = model.generate_content(full_prompt)

        # Extract the text from the AI's response
        # The 'text' attribute contains the generated content.
        ai_response_text = response.text

        # Return the AI's response as JSON
        return jsonify({'response': ai_response_text})

    except Exception as e:
        # Catch any errors during the process and return an error message
        print(f"Error processing request: {e}")
        return jsonify({'error': 'An internal server error occurred', 'details': str(e)}), 500

# Run the Flask application
if __name__ == '__main__':
    # The server will run on http://127.0.0.1:5000/
    # debug=True allows for automatic reloading on code changes (useful during development)
    app.run(debug=True, port=5000)
