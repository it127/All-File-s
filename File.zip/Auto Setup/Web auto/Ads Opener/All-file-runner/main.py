import subprocess
import os
import time
import random
import logging
import sys
import win32con
import win32process
import win32gui
import win32api

# Configure logging
logging.basicConfig(
    filename='process_manager.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# List of Python files to run
python_files = [
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome\copy\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 1\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 1\copy\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 2\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 2\copy\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 3\main.py",
    r"C:\Auto Setup\Web auto\Ads Opener\Ads Google Chrome - Copy 3\copy\main.py",
]

def hide_console_window(pid):
    """Hide the console window of the process"""
    try:
        def callback(hwnd, hwnds):
            if win32gui.IsWindowVisible(hwnd):
                _, found_pid = win32process.GetWindowThreadProcessId(hwnd)
                if found_pid == pid:
                    hwnds.append(hwnd)
            return True
        
        hwnds = []
        win32gui.EnumWindows(callback, hwnds)
        for hwnd in hwnds:
            win32gui.ShowWindow(hwnd, win32con.SW_HIDE)
    except Exception as e:
        logging.error(f"Error hiding window for PID {pid}: {str(e)}")

def human_like_delay():
    """Random delay to simulate human behavior"""
    delay = random.uniform(1.5, 10.5)  # Random delay between 1.5 to 10.5 seconds
    time.sleep(delay)

def run_hidden_process(command):
    """Run a process with hidden window"""
    try:
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        process = subprocess.Popen(
            command,
            startupinfo=startupinfo,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.DETACHED_PROCESS
        )
        
        # Additional hiding for extra reliability
        hide_console_window(process.pid)
        
        return process
    except Exception as e:
        logging.error(f"Error starting hidden process: {str(e)}")
        return None

def run_and_monitor(files):
    """Monitor and maintain the processes"""
    processes = {}
    
    while True:
        for file in files:
            try:
                # Check if process needs to be started
                proc = processes.get(file)
                if proc is None or proc.poll() is not None:
                    if os.path.exists(file):
                        logging.info(f"Starting process: {file}")
                        
                        # Human-like delay before starting
                        human_like_delay()
                        
                        # Run the process hidden
                        processes[file] = run_hidden_process(['python', file])
                        
                        if processes[file] is None:
                            logging.error(f"Failed to start process: {file}")
                            del processes[file]
                    else:
                        logging.warning(f"File not found: {file}")
                
                # Random check interval to simulate human behavior
                time.sleep(random.uniform(3, 15))
                
            except Exception as e:
                logging.error(f"Error in monitoring loop for {file}: {str(e)}")
                time.sleep(30)  # Longer delay after error

def main():
    try:
        # Hide our own console window if running in console mode
        hide_console_window(os.getpid())
        
        logging.info("Process manager started")
        run_and_monitor(python_files)
    except KeyboardInterrupt:
        logging.info("Process manager stopped by user")
        sys.exit(0)
    except Exception as e:
        logging.critical(f"Fatal error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    # For complete stealth, you could package this as a Windows service
    # But this version will run hidden as a regular script
    main()