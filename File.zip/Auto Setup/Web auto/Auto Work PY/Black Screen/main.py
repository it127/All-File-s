import tkinter as tk

root = tk.Tk()
root.attributes('-fullscreen', True)
root.configure(bg='black')
root.attributes('-topmost', True)

def close_app():
	root.destroy()

close_btn = tk.Button(root, text="Close", command=close_app, font=("Arial", 7), bg="black", fg="white")
close_btn.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

root.mainloop()