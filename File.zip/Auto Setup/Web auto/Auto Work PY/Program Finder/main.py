import psutil

def count_running_python_programs():
    python_processes = 0
    
    for process in psutil.process_iter(['name', 'cmdline']):
        try:
            # Check if the process name contains 'python' or if python is in the command line
            if 'python' in process.info['name'].lower() or \
               (process.info['cmdline'] and 'python' in ' '.join(process.info['cmdline']).lower()):
                python_processes += 1
                # Optional: Print details of each Python process
                print(f"Python process found - PID: {process.pid}, Name: {process.info['name']}, Cmdline: {' '.join(process.info['cmdline'])}")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            # Process may have died or we don't have permissions
            continue
    
    return python_processes

if __name__ == "__main__":
    count = count_running_python_programs()
    print(f"\nTotal running Python programs: {count}")