import os
import subprocess
import winreg

def find_startup_files():
    """Find startup files in common Windows 10 startup locations"""
    startup_files = []
    
    # Common startup locations
    locations = [
        # Current user startup folder
        os.path.join(os.environ['APPDATA'], 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup'),
        # All users startup folder
        os.path.join(os.environ['PROGRAMDATA'], 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'StartUp'),
        # Registry startup locations
    ]
    
    # Check file system locations
    for location in locations:
        if os.path.exists(location):
            for item in os.listdir(location):
                full_path = os.path.join(location, item)
                if os.path.isfile(full_path):
                    startup_files.append(full_path)
    
    # Check registry startup locations
    registry_locations = [
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
        (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
    ]
    
    for hive, key_path in registry_locations:
        try:
            with winreg.OpenKey(hive, key_path) as key:
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(key, i)
                        # Only include files that exist
                        if os.path.exists(value):
                            startup_files.append(f"Registry: {name} -> {value}")
                        i += 1
                    except OSError:
                        break
        except WindowsError:
            pass
    
    return startup_files

def open_file(file_path):
    """Open a file with the default application"""
    try:
        if file_path.startswith("Registry: "):
            print(f"Cannot directly open registry entry: {file_path}")
            return False
        
        if os.path.exists(file_path):
            os.startfile(file_path)
            return True
        else:
            print(f"File not found: {file_path}")
            return False
    except Exception as e:
        print(f"Error opening file: {e}")
        return False

def main():
    print("Finding Windows 10 startup files...")
    startup_files = find_startup_files()
    
    if not startup_files:
        print("No startup files found.")
        return
    
    print("\nFound startup files:")
    for i, file_path in enumerate(startup_files, 1):
        print(f"{i}. {file_path}")
    
    while True:
        try:
            choice = input("\nEnter the number of the file to open (or 'q' to quit): ")
            if choice.lower() == 'q':
                break
            
            index = int(choice) - 1
            if 0 <= index < len(startup_files):
                file_path = startup_files[index]
                if file_path.startswith("Registry: "):
                    print(f"\nRegistry entries cannot be directly opened. Here's the information:")
                    print(file_path)
                else:
                    print(f"\nOpening: {file_path}")
                    if open_file(file_path):
                        print("File opened successfully.")
                    else:
                        print("Failed to open file.")
            else:
                print("Invalid selection. Please try again.")
        except ValueError:
            print("Please enter a valid number or 'q' to quit.")

if __name__ == "__main__":
    main()