#!/usr/bin/env python3
"""
WiFi Password Finder Script

This script uses pywifi library to scan nearby WiFi networks 
and retrieve their SSIDs and BSSIDs. Results are saved to 'wifi_passwords.txt'.
"""

import sys
import time
import os.path
from pywifi import PyWiFi, const, Profile

def save_password(ssid, bssid, filename='wifi_passwords.txt'):
    """Append WiFi credentials to output file."""
    try:
        with open(filename, 'a') as f:
            f.write(f"{ssid} | {bssid}\n")
        print(f"[+] Saved '{ssid}' ({bssid}) to {filename}")
    except Exception as e:
        print(f"Error saving data: {e}")

def find_wifi_password(ssid):
    # Initialize WiFi object
    wifi = PyWiFi()
    
    # Get available interfaces
    iface = wifi.interfaces()[0]
    
    # Scan all available networks
    print("[*] Scanning available WiFi networks...")
    iface.scan()
    
    # Wait for scanning completion
    time.sleep(5)
    
    # Retrieve scan results
    scan_results = iface.scan_results()
    
    # Search for target SSID
    for network in scan_results:
        if network.ssid == ssid:
            save_password(network.ssid, network.bssid)
            return f"[+] Found WiFi Network: {ssid}, BSSID: {network.bssid}"
    
    return "[-] WiFi network not found."

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python wifi_finder.py <SSID>")
        sys.exit(1)
    
    ssid_to_find = sys.argv[1]
    
    # Check/create output file
    if not os.path.exists('wifi_passwords.txt'):
        with open('wifi_passwords.txt', 'w') as f:
            f.write("# Discovered WiFi Networks\nTimestamp: {}\n".format(time.strftime("%Y-%m-%d %H:%M:%S")))
    
    result = find_wifi_password(ssid_to_find)
    print(result)